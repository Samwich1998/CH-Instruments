# CH-Instruments
Python code to perform data analysis on CH Instruments Electrochemical Runs. Data MUST be exported from the CHI '.bin' file into a '.CSV' file.
All code has been tested on a Mac (though it should work on a Windows/Linux system as well).
Parameters that the User should edit are delimited at the top of the code (mainly the path from the .py file to the .csv files).
